package st10077892icetask1prog6112;

import java.util.Arrays;
import java.util.Scanner;

public class ST10077892IceTask1PROG6112 {

    public static void main(String[] args) {
        // Phase 1: Create an array with five book titles
        String[] books = {"Harry Potter", "The Great Gatsby", "To Kill a Mockingbird", "Pride and Prejudice", "Othello"};

        // Phase 4: Prompt the user whether they would like to use the insertion sort algorithm in ascending or descending order
        Scanner scanner = new Scanner(System.in);
        System.out.println("Would you like to sort the books in ascending or descending order? (Enter 'asc' for ascending, 'desc' for descending)");
        String userChoice = scanner.nextLine();

        // Sort the array based on user choice and display the sorted array
        if (userChoice.equalsIgnoreCase("asc")) {
            insertionSortAscending(books);
            System.out.println("Books sorted in ascending order:");
        } else if (userChoice.equalsIgnoreCase("desc")) {
            insertionSortDescending(books);
            System.out.println("Books sorted in descending order:");
        } else {
            System.out.println("Invalid choice. Please enter 'asc' or 'desc'.");
            return; // Exit the program if the choice is invalid
        }

        // Display the sorted array
        System.out.println(Arrays.toString(books));
    }

    // Phase 2: Using the insertion sort algorithm, create a method for sorting the array in ascending order
    public static void insertionSortAscending(String[] arr) {
        for (int i = 1; i < arr.length; i++) {
            String key = arr[i];
            int j = i - 1;

            // Move elements of arr[0..i-1], that are greater than key, to one position ahead of their current position
            while (j >= 0 && arr[j].compareTo(key) > 0) {
                arr[j + 1] = arr[j];
                j = j - 1;
            }
            arr[j + 1] = key;
        }
    }

    // Phase 3: Using the insertion sort algorithm, create a method for sorting the array in descending order
    public static void insertionSortDescending(String[] arr) {
        for (int i = 1; i < arr.length; i++) {
            String key = arr[i];
            int j = i - 1;

            // Move elements of arr[0..i-1], that are less than key, to one position ahead of their current position
            while (j >= 0 && arr[j].compareTo(key) < 0) {
                arr[j + 1] = arr[j];
                j = j - 1;
            }
            arr[j + 1] = key;
        }
    }
}

